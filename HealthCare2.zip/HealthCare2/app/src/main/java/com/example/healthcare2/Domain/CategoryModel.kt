package com.example.healthcare2.Domain

data class CategoryModel(
    val Id : Int=0,
    val Name: String="",
    val Picture:String=""
)
