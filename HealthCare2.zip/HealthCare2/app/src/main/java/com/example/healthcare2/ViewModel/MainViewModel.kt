package com.example.healthcare2.ViewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.healthcare2.Domain.CategoryModel
import com.example.healthcare2.Domain.DoctorModles
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Locale.Category

class MainViewModel(): ViewModel() {
    private val firebaseDatabase=FirebaseDatabase.getInstance()
    private val _category=MutableLiveData<MutableList<CategoryModel>>()
    private val _doctors =MutableLiveData<MutableList<DoctorModles>>()


    val category: LiveData<MutableList<CategoryModel>> =_category
    val doctors: LiveData<MutableList<DoctorModles>> =_doctors


    fun loadCategory(){
        val Ref = firebaseDatabase.getReference("Category")
        Ref.addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                val lists=mutableListOf<CategoryModel>()
                for(childSnapshot in snapshot.children){
                    val list=childSnapshot.getValue(CategoryModel::class.java)
                    if(list!=null){
                        lists.add(list)
                    }
                }
                _category.value=lists
            }
            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })
    }

    fun loadDoctors(){

        val Ref=firebaseDatabase.getReference("Doctors")
        Ref.addValueEventListener(object :ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                val lists= mutableListOf<DoctorModles>()

                for (childSnapshot in  snapshot.children) {
                    val list=childSnapshot.getValue(DoctorModles::class.java)
                    if (list!=null){
                        lists.add(list)
                    }
                }

                _doctors.value=lists

            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        }
        )

    }

}