package com.example.healthcare2.Domain

import android.os.Parcel
import android.os.Parcelable
import java.nio.file.Paths
import kotlin.contracts.Returns

data class DoctorModles(
    val Address:String="",
    val Biography:String="",
    val Id:Int=0,
    val Name:String="",
    val Picture:String="",
    val Special:String="",
    val Exprience:Int=0,
    val Location:String="",
    val Mobile:String="",
    val patiens:String="",
    val Rating: Double=0.0,
    val Site:String=""


):Parcelable{
    constructor(parcel: Parcel):this(
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.readInt(),
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.readInt(),
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.readDouble(),
        parcel.readString().toString()


    ){

    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(Address)
        parcel.writeString(Biography)
        parcel.writeInt(Id)
        parcel.writeString(Name)
        parcel.writeString(Picture)
        parcel.writeString(Special)
        parcel.writeInt(Exprience)
        parcel.writeString(Location)
        parcel.writeString(Mobile)
        parcel.writeString(patiens)
        parcel.writeDouble(Rating)
        parcel.writeString(Site)


    }

    override fun describeContents(): Int {
       return 0

    }


    companion object CREATOR : Parcelable.Creator<DoctorModles> {
        override fun createFromParcel(p0: Parcel?): DoctorModles {
            TODO("Not yet implemented")
        }

        override fun newArray(p0: Int): Array<DoctorModles> {
            TODO("Not yet implemented")
        }
    }

    fun createFromParcel(parcel: Parcel):DoctorModles{
        return DoctorModles(parcel)
    }

    fun newArray(size:Int): Array<DoctorModles?>{
        return arrayOfNulls(size)

    }

    fun add(function: () -> DoctorModles) {

    }
}
